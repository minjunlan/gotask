<?php
// +----------------------------------------------------------------------
// | 宝塔服务器助手[Linux面板]
// +----------------------------------------------------------------------
// | Copyright (c) 2015-2016 宝塔软件(http://bt.cn) All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 黄文良 <2879625666@qq.com>
// +----------------------------------------------------------------------

//----------------------------------
// 系统设置
//----------------------------------
require './Common.php';

//服务管理
function ServiceAdmin(){
	$name = I('name');
	$type = I('type');
	if($name == 'apache' || $name == 'httpd'){
		$name = 'httpd';
		SendSocket("ExecShell|/www/server/apache/bin/apachectl -t");
		$result = trim(file_get_contents('/tmp/shell_temp.pl'));
		if(strpos($result,'Syntax OK') === false){
			WriteLogs("环境设置", $exec."执行失败: ".$result);
			returnJson(false,'Apache配置规则错误: <br><a style="color:red;">'.str_replace("\n",'<br>',$result).'</a>');
		}
	} 
	if($name == 'nginx'){
		SendSocket("ExecShell|nginx -t -c /www/server/nginx/conf/nginx.conf");
		$result = file_get_contents('/tmp/shell_temp.pl');
		if(!strpos($result,'successful')){
			WriteLogs("环境设置", $exec."执行失败: ".$result);
			returnJson(false,'Nginx配置规则错误: <br><a style="color:red;">'.str_replace("\n",'<br>',$result).'</a>');
		}
	}
	
	
	if($type == 'test') returnJson(true, '配置检测通过!');
	$exec = "service $name $type";
	if($exec == 'service pure-ftpd reload') $exec = '/www/server/pure-ftpd/bin/pure-pw mkdb /www/server/pure-ftpd/etc/pureftpd.pdb';
	if($name == 'nginx' && $type == 'restart'){
		SendSocket("ExecShell|pkill -9 nginx");
		SendSocket("ExecShell|service nginx start");
	}else{
		$result = SendSocket("ExecShell|$exec");
		$tmp = trim(file_get_contents('/tmp/shell_temp.pl'));
		if(strpos($tmp,'nginx.pid')){
			SendSocket("ExecShell|pkill -9 nginx && sleep 1");
			SendSocket("ExecShell|service nginx start");
		}
	}
	
	
	WriteLogs("环境设置", $exec."执行成功!");
	ajax_return($result);
}

//停用指定PHP版本
function StopPHPVersion(){
	$version = I('version');
	$panelVersion = substr(str_replace('.','',PHP_VERSION),0,2);
	if($version == $panelVersion) returnJson(false, '当前PHP版本正在被面板使用!');
	
	$filename = '/etc/init.d/php-fpm-'.$version;
	$filename_backup = '/etc/init.d/php-fpm-'.$version.'_backup';
	if(file_exists($filename)){
		SendSocket("ExecShell|service php-fpm-".$version." stop");
		SendSocket("FileAdmin|MvDirOrFile|" . $filename . '|'.$filename_backup);
	}
	returnJson(true, 'PHP-'.$version.' 已停用!');
}

//启用指定PHP版本
function StartPHPVersion(){
	$version = I('version');
	$filename = '/etc/init.d/php-fpm-'.$version;
	$filename_backup = '/etc/init.d/php-fpm-'.$version.'_backup';
	if(file_exists($filename_backup)){
		SendSocket("FileAdmin|MvDirOrFile|" . $filename_backup. '|'.$filename);
		SendSocket("FileAdmin|ChownFile|" . $filename . '|root');
		SendSocket("FileAdmin|ChmodFile|" . $filename . '|755');
	}
	
	if(file_exists($filename)){
		SendSocket("ExecShell|service php-fpm-".$version." start");
		returnJson(true, 'PHP-'.$version.' 已启用!');
	}
	
	returnJson(false, $filename_backup.'文件不存在!');
}

//设置面板SSL
function SetPanelSSL(){
	$file = $_SESSION['server_type'] == 'nginx' ? '/www/server/nginx/conf/nginx.conf':'/www/server/apache/conf/extra/httpd-vhosts.conf';
	$conf = file_get_contents($file);
	$panel = GetPanelBinding();
	$panel['script_name'] = $_SERVER['SCRIPT_NAME'];
	if($panel['domain'] == 'www.bt.cn'){
		$tmp = explode(':', $_SERVER['HTTP_HOST']);
		$panel['domain'] = $tmp[0];
	}
	if($panel['port'] == '80') returnJson(false,'面板端口不能为80');
	if($panel['ssl']){
		if($_SESSION['server_type'] == 'nginx'){
			$rep = "/\s+ssl_certificate\s+.+;\s+ssl_certificate_key\s+.+;\n/";
			$conf = preg_replace($rep,'',$conf);
			$rep = "/listen\s+".$panel['port']."\s+ssl;/";
			$conf = preg_replace($rep,'listen '.$panel['port'].';',$conf);
			$rep = "/\s+error_page\s497.+;\n/";
			$conf = preg_replace($rep,'',$conf);
		}else{
			if(strpos($conf, 'combined')){
				$rep = "combined\nSSLEngine On\nSSLCertificateFile conf/key/default/key.csr\nSSLCertificateKeyFile conf/key/default/key.key";
				$conf = str_replace($rep,'combined',$conf);
			}else{
				$rep = "example.com\nSSLEngine On\nSSLCertificateFile conf/key/default/key.csr\nSSLCertificateKeyFile conf/key/default/key.key";
				$conf = str_replace($rep,'example.com',$conf);
			}
			
		}
		
		
		if (file_put_contents('/tmp/read.tmp', $conf)) {
			$result = SendSocket("FileAdmin|SaveFile|" . $file);
			if($result['status']) WriteLogs("环境设置", "开启面板SSL成功!");
			serviceWebReload();
			$panel['status'] = true;
			$panel['msg'] = '已关闭SSL，请使用http协议访问面板!';
			$panel['type'] = 'http://';
			ajax_return($panel);
		}
		
		returnJson(false, '操作失败!');		
	}
	
	
	if($_SESSION['server_type'] == 'nginx'){
		$rep = "/listen\s+".$panel['port']."\s*;/";
		$conf = preg_replace($rep,'listen '.$panel['port'].' ssl;',$conf);
		$sslStr = "#error_page   404   /404.html;\n		ssl_certificate	key/default/key.csr;\n		ssl_certificate_key  key/default/key.key;\n		error_page 497  https://\$host:\$server_port\$uri;\n";
		$conf = str_replace('#error_page   404   /404.html;',$sslStr,$conf);
	}else{
		if(strpos($conf, 'combined')){
			$conf = str_replace('combined', "combined\nSSLEngine On\nSSLCertificateFile conf/key/default/key.csr\nSSLCertificateKeyFile conf/key/default/key.key", $conf);
		}else{
			$conf = str_replace('example.com', "example.com\nSSLEngine On\nSSLCertificateFile conf/key/default/key.csr\nSSLCertificateKeyFile conf/key/default/key.key", $conf);
		}
		
	}
	
	//生成证书
	$dn = array(  
   	 	"countryName" 			=> 'CN', 				
   	 	"stateOrProvinceName"	=> 'GuangDong', 
   	 	"localityName" 			=> 'Dongguan', 
  	 	"organizationName" 		=>	'bt.cn', 
    	"organizationalUnitName" => 'BT-WebPanel',
    	"commonName" 			=> $panel['domain'],
    	"emailAddress" 			=> 'ssltest@bt.cn'
 	);  
	$numberofdays = 3650;     				//有效时长 
	$path =   "/www/server/".$_SESSION['server_type']."/conf/key/default";
	if(!file_exists($path)){
		SendSocket("FileAdmin|AddDir|" . $path);
	}
	$csrpath = $path."/key.csr";				//生成证书路径  
	$keypath = $path."/key.key"; 				//密钥文件路径  
	if(!file_exists($csrpath)){
		$privkey = openssl_pkey_new();  
		$csr = openssl_csr_new($dn, $privkey);  
		$sscert = openssl_csr_sign($csr, null, $privkey, $numberofdays);  
		openssl_x509_export($sscert, $csrkey);
		openssl_pkey_export($privkey, $privatekey);
		file_put_contents('/tmp/read.tmp', $privatekey);
		SendSocket("FileAdmin|SaveFile|" . $keypath);
		file_put_contents('/tmp/read.tmp', $csrkey);
		SendSocket("FileAdmin|SaveFile|" . $csrpath);
	}
	if (file_put_contents('/tmp/read.tmp', $conf)) {
		$result = SendSocket("FileAdmin|SaveFile|" . $file);
		if($result['status']) WriteLogs("环境设置", "开启面板SSL成功!");
		serviceWebReload();
		$panel['status'] = true;
		$panel['msg'] = '已开启SSL，请使用SSL协议访问面板!';
		$panel['type'] = 'https://';
		ajax_return($panel);
	}
	returnJson(false, '操作失败!');
}

//设置面板端口和域名
function SetPanelBinding(){
	$port 	= I('port','','intval');
	$domain = I('domain');
	if(intval($port) > 9999 || intval($port) < 888) returnJson(false, '端口范围不合法(888 - 8888)!');
	$panel = GetPanelBinding();
	$file = $_SESSION['server_type'] == 'nginx' ? '/www/server/nginx/conf/nginx.conf':'/www/server/apache/conf/extra/httpd-vhosts.conf';
	$conf = file_get_contents($file);
	if($port != $panel['port']){
		$conf = str_replace($panel['port'],$port,$conf);
		//添加防火墙
		SendSocket("Firewall|AddFireWallPort|".$port."|TCP|webPanel");
		//修改防火墙列表
		M('firewall')->where("port='".$panel['port']."'")->setField('port',$port);
	}
	
	if($domain != $panel['domain'] && strlen($domain) > 3){
		$conf = str_replace($panel['domain'],$domain,$conf);
		$_SESSION['bindingDomain'] = $domain;
	}
	
	if (file_put_contents('/tmp/read.tmp', $conf)) {
		$result = SendSocket("FileAdmin|SaveFile|" . $file);
		if($result['status']) WriteLogs("环境设置", "将面板端口改为[$port],绑定域名[$domain]!");
		return true;
	}
	return false;
}

//设置是否开启访问限制
function SetPanelLimit(){
	$limit = file_get_contents('./conf/limit.conf');
	if($limit == 'true'){
		file_put_contents('./conf/limit.conf','false');
	}else{
		file_put_contents('./conf/limit.conf','true');
	}
	returnJson(true, '操作成功!');	
}

//保存配置
function SaveConfig(){
	$result['status']  = false;
	$result['status'] = SetPanelBinding();
	
	$data = array(
		'sites_path'	=>	I('sites_path'),
		'backup_path'	=>	I('backup_path')
	);
	
	if(M('config')->where("id=1")->save($data)){
		$_SESSION['config']['sites_path'] = $data['sites_path'];
		$_SESSION['config']['backup_path'] = $data['backup_path'];
		SendSocket("FileAdmin|AddDir|".$data['sites_path']);
		SendSocket("FileAdmin|AddDir|".$data['backup_path'].'/database');
		SendSocket("FileAdmin|AddDir|".$data['backup_path'].'/site');
		$result['status'] = true;
	}
	
	if($_POST['ip'] != $_SESSION['iplist']){
		file_put_contents("./conf/iplist.conf",$_POST['ip']);
		$_SESSION['iplist'] = $_POST['ip'];
		$result['status'] = true;
		WriteLogs("环境设置", "更新服务器IP为[".$_POST['ip']."]!");
	}
	
	if(isset($_POST['panel_name'])){
		file_put_contents('./conf/panelName.conf', $_POST['panel_name']);
		$result['status'] = true;
		$_SESSION['version'] = $_POST['panel_name'];
	}
	
	$result['msg'] = $result['status']?'配置已保存':'没有做任何改变';
	if($result['status']){
		$panel = GetPanelBinding();
		$result['port'] = I('port');
		$result['domain'] = I('domain');
		$result['script_name'] = $_SERVER['SCRIPT_NAME'];
		$result['type'] = $panel['ssl']?'https://':'http://';
		if($result['domain'] == 'www.bt.cn') $result['domain'] = $_SESSION['serverip'];
	}
	
	ajax_return($result);
}

//设置pathInfo支持
function SetPathInfo(){
	$version = I('version');
	$type = I('type');
	
	if($_SESSION['server_type'] == 'nginx'){
		$path = '/www/server/nginx/conf/enable-php-'.$version.'.conf';
		$conf = file_get_contents($path);
		$rep = "/\s+#*include\s+pathinfo.conf;/";
		if($type == 'on'){
			$conf = preg_replace($rep,"\n\t\t\tinclude pathinfo.conf;",$conf);
		}else{
			$conf = preg_replace($rep,"\n\t\t\t#include pathinfo.conf;",$conf);
		}
		file_put_contents('/tmp/read.tmp',$conf);
		SendSocket("FileAdmin|SaveFile|" . $path);
	}
	$path = '/www/server/php/'.$version.'/etc/php.ini';
	$conf = file_get_contents($path);
	$rep = "/\n;*\s*cgi\.fix_pathinfo\s*=\s*([0-9]+)\s*\n/";
	$status = $type == 'on' ? '1':'0';
	$conf = preg_replace($rep, "\ncgi.fix_pathinfo = $status\n", $conf);
	file_put_contents('/tmp/read.tmp',$conf);
	SendSocket("FileAdmin|SaveFile|" . $path);
	if($result['status']) WriteLogs("环境设置", "设置PHP-${version} PATH_INFO模块为[{$type}]!");
	SendSocket("ExecShell|service php-fpm-$version reload");
	returnJson(true,'设置成功!');	
}

//设置PHP文件上传大小限制
function SetPHPMaxSize(){
	$version = $_GET['version'];
	$max = intval($_GET['max']);
	
	//设置PHP
	$path = '/www/server/php/'.$version.'/etc/php.ini';
	$conf = file_get_contents($path);
	$rep = "/^upload_max_filesize\s*=\s*[0-9]+M/m";
	$conf = preg_replace($rep,'upload_max_filesize = '.$max.'M',$conf);
	$rep = "/^post_max_size\s*=\s*[0-9]+M/m";
	$conf = preg_replace($rep,'post_max_size = '.$max.'M',$conf);
	if(file_put_contents('/tmp/read.tmp',$conf)){
		$result = SendSocket("FileAdmin|SaveFile|" . $path);
	}
	
	if($_SESSION['server_type'] == 'nginx'){
		//设置Nginx
		$path = '/www/server/nginx/conf/nginx.conf';
		$conf = file_get_contents($path);
		$rep = "/client_max_body_size\s+([0-9]+)m/m";
		preg_match($rep,$conf,$tmp);
		if(intval($tmp[1]) < intval($max)){
			$conf = preg_replace($rep,'client_max_body_size '.$max.'m',$conf);
			if(file_put_contents('/tmp/read.tmp',$conf)){
				$result = SendSocket("FileAdmin|SaveFile|" . $path);
			}
		}
	}
	serviceWebReload();
	SendSocket("ExecShell|service php-fpm-$version reload");
	if($result['status']) WriteLogs("环境设置", "设置PHP最大上传大小为[{$max}MB]!");
	returnJson(true,'设置成功!');	
}

//设置PHP超时时间
function SetPHPMaxTime(){
	$time = I('time','','intval');
	$version = I('version','','intval');
	if($time < 30 || $time > 86400*30) returnJson(false,'请填写30-86400*30间的值!');
	$file = '/www/server/php/'.$version.'/etc/php-fpm.conf';
	$conf = file_get_contents($file);
	$rep = "/request_terminate_timeout\s*=\s*([0-9]+)\n/";
	$conf = preg_replace($rep,"request_terminate_timeout = ".$time."\n",$conf);	
	if(file_put_contents('/tmp/read.tmp',$conf)){
		$result = SendSocket("FileAdmin|SaveFile|" . $file);
	}
	
	if($_SESSION['server_type'] == 'nginx'){
		//设置Nginx
		$path = '/www/server/nginx/conf/nginx.conf';
		$conf = file_get_contents($path);
		$rep = "/fastcgi_connect_timeout\s+([0-9]+);/";
		preg_match($rep, $conf,$tmp);
		if(intval($tmp[1]) < $time){
			$conf = preg_replace($rep,'fastcgi_connect_timeout '.$time.';',$conf);
			$rep = "/fastcgi_send_timeout\s+([0-9]+);/";
			$conf = preg_replace($rep,'fastcgi_send_timeout '.$time.';',$conf);
			$rep = "/fastcgi_read_timeout\s+([0-9]+);/";
			$conf = preg_replace($rep,'fastcgi_read_timeout '.$time.';',$conf);
			 
			if(file_put_contents('/tmp/read.tmp',$conf)){
				$result = SendSocket("FileAdmin|SaveFile|" . $path);
			}
		}
	}
	if($result['status']) WriteLogs("环境设置", "设置PHP最大脚本超时时间为[{$time}秒]!");
	serviceWebReload();
	SendSocket("ExecShell|service php-fpm-$version reload");
	returnJson(true, '保存成功!');
}

//设置防恶意解析
function SetDefaultSite(){
	if($_SESSION['server_type'] != 'nginx') return;
	$file = '/www/server/nginx/conf/vhost/default.conf';
	if(file_exists($file)) {
		SendSocket("FileAdmin|DelFile|".$file);
	}else{
		$conf=<<<EOT
server {
	listen 80 default_server;
	server_name _;
	root /www/server/nginx/html;
}
EOT;

		if (file_put_contents('/tmp/read.tmp', $conf)) {
			SendSocket("FileAdmin|SaveFile|".$file);
		}
	}
	serviceWebReload();
	returnJson(true, '设置成功!');
}

//取FPM设置
function GetFpmConfig(){
	$version = I('version');
	$file = "/www/server/php/$version/etc/php-fpm.conf";
	$conf = file_get_contents($file);
	$rep = "/\s*pm.max_children\s*=\s*([0-9]+)\s*/";
	preg_match($rep, $conf,$tmp);
	$data['max_children'] = $tmp[1];
	
	$rep = "/\s*pm.start_servers\s*=\s*([0-9]+)\s*/";
	preg_match($rep, $conf,$tmp);
	$data['start_servers'] = $tmp[1];
	
	$rep = "/\s*pm.min_spare_servers\s*=\s*([0-9]+)\s*/";
	preg_match($rep, $conf,$tmp);
	$data['min_spare_servers'] = $tmp[1];
	
	$rep = "/\s*pm.max_spare_servers \s*=\s*([0-9]+)\s*/";
	preg_match($rep, $conf,$tmp);
	$data['max_spare_servers'] = $tmp[1];
	
	ajax_return($data);
}

//设置
function SetFpmConfig(){
	$version = I('version');
	$max_children = I('max_children');
	$start_servers = I('start_servers');
	$min_spare_servers = I('min_spare_servers');
	$max_spare_servers = I('max_spare_servers');
	
	$file = "/www/server/php/$version/etc/php-fpm.conf";
	$conf = file_get_contents($file);
	
	$rep = "/\s*pm.max_children\s*=\s*([0-9]+)\s*/";
	$conf = preg_replace($rep, "\npm.max_children = ".$max_children, $conf);
	
	$rep = "/\s*pm.start_servers\s*=\s*([0-9]+)\s*/";
	$conf = preg_replace($rep, "\npm.start_servers = ".$start_servers, $conf);
	
	$rep = "/\s*pm.min_spare_servers\s*=\s*([0-9]+)\s*/";
	$conf = preg_replace($rep, "\npm.min_spare_servers = ".$min_spare_servers, $conf);
	
	$rep = "/\s*pm.max_spare_servers \s*=\s*([0-9]+)\s*/";
	$conf = preg_replace($rep, "\npm.max_spare_servers = ".$max_spare_servers."\n", $conf);
	if(file_put_contents('/tmp/read.tmp',$conf)){
		$result = SendSocket("FileAdmin|SaveFile|" . $file);
	}
	SendSocket("ExecShell|service php-fpm-$version reload");
	returnJson(true, '设置成功');
}

//自动更新
function SetPanelAutoUpload(){
	$limit = file_get_contents('./conf/upload.conf');
	if($limit == 'true'){
		file_put_contents('./conf/upload.conf','false');
	}else{
		file_put_contents('./conf/upload.conf','true');
	}
	returnJson(true, '操作成功!');	
}

//获取插件列表
function GetLibList(){
	$libConf = C('lib');
	for($i=0;$i<count($libConf);$i++){
		$libConf[$i]['status'] = CheckLibStatus($libConf[$i]['check']);
		$libConf[$i]['optstr'] = GetLibOpt($libConf[$i]['status'],$libConf[$i]['opt']);
	}
	ajax_return($libConf);
}

//取插件操作选项
function GetLibOpt($status,$libName){
	$optStr = '';
	if($status == '未安装'){
		$optStr = '<a class="link" href="javascript:InstallLib(\''.$libName.'\');">安装</a>';
	}else{
		$optStr = '<a class="link" href="javascript:SetLibConfig(\''.$libName.'\');">配置</a> | <a class="link" href="javascript:UninstallLib(\''.$libName.'\');">卸载</a>';
	}
	return $optStr;
}

//检查插件是否安装
function CheckLibStatus($checkArr){
	foreach($checkArr as $value){
		if(file_exists($value)) return '已安装';
	}
	return '未安装';
}

//取七牛AS
function GetQiniuAS(){
	$filename = '/www/server/cloud/qiniuAs.conf';
	SendSocket("FileAdmin|ReadFile|".$filename);
	$data = explode('|', file_get_contents('/tmp/read.tmp'));
	if(count($data) < 3){
		$data = array('','','','');
	}
	ajax_return($data);
}

//设置七牛AS
function SetQiniuAS(){
	$filename = '/www/server/cloud/qiniuAs.conf';
	$conf = I('access_key','','trim').'|'.I('secret_key','','trim').'|'.I('bucket_name','','trim').'|'.I('bucket_domain','','trim');
	if(file_put_contents('/tmp/read.tmp',$conf)){
		SendSocket("FileAdmin|SaveFile|". $filename);
		SendSocket("FileAdmin|ChmodFile|" . $filename . '|600');
		SendSocket("FileAdmin|ChownFile|" . $filename . '|root');
	}
	SendSocket("ExecShell|python backup_qiniu.py list|/www/server/cloud");
	$result = trim(file_get_contents('/tmp/shell_temp.pl'));
	if($result != 'null') returnJson(true, '设置成功!');
	returnJson(false, '测试失败，请检查[AK/SK/存储空间]设是否正确!');
}

//安装插件
function InstallLib(){
	$info = GetLibInfo(I('name'));
	if(!$info) returnJson(false, '插件信息获取失败!');
	$url = 'http://www.bt.cn:5880/lib/script/qiniu.sh';
	$filename = '/www/server/cloud/qiniu_install.sh';
	$pdata = file_get_contents($url);	
	if(file_put_contents('/tmp/read.tmp', $pdata)){
		SendSocket("FileAdmin|SaveFile|" . $filename);
		$result = SendSocket("ExecShell|nohup sh ".$filename." install ",60,60);
		returnJson(true,'已开始安装，请稍候!');
	}
	returnJson(false,'安装失败!');
}

//卸载插件
function UninstallLib(){
	$filename = '/www/server/cloud/qiniu_install.sh';
	$result = SendSocket("ExecShell|nohup sh ".$filename." uninstall ",60,60);
	ajax_return($result);
}

//获取指定插件信息
function GetLibInfo($name){
	$libList = C('lib');
	foreach($libList as $info){
		if($name == $info['opt']) return $info;
	}
	
	return false;
}

//获取七牛空间文件列表
function GetQiniuFileList(){
	SendSocket("ExecShell|python backup_qiniu.py list|/www/server/cloud",30,30);
	$tmp = explode('[',file_get_contents('/tmp/shell_temp.pl'));
	$data = json_decode(trim('['.$tmp[1]));
	if($data == null) returnJson(false, '获取列表失败,请检查[AK/SK/存储空间]设是否正确!');
	array_multisort($data ,SORT_DESC,SORT_NUMERIC,$data);
	ajax_return($data);
}

//关闭面板
function ClosePanel(){
	$filename = '/www/wwwroot/default/conf/close.pl';
	$result = file_put_contents($filename, 'True');
	if($result){
		SendSocket("chmod 644 ".$filename);
		SendSocket("chown root.root ".$filename);
		returnJson(true, '宝塔面板已关闭!');
	}
	returnJson(true, '关闭失败!');
}


//获取MySQL内存配置
function GetMySQLMemConf(){
	$conf = file_get_contents('/etc/my.cnf');
	
	$data = array();
	
	$caches = array(
					array(
						'name'	=> 'table_open_cache',
						'ps'	=> "table_cache指定表高速缓存的大小。每当MySQL访问一个表时，如果在表缓冲区中还有空间，该表就被打开并放入其中，这样可以更快地访问表内容。通过检查峰值时间的状态值Open_tables和Opened_tables，可以决定是否需要增加table_cache的值。如果你发现open_tables等于table_cache，并且opened_tables在不断增长，那么你就需要增加table_cache的值了",
						'value'	=> '',	
						),
					array(
						'name'	=> 'query_cache_size',
						'ps'	=> "主要用来缓存MySQL中的ResultSet，也就是一条SQL语句执行的结果集，所以仅仅只能针对select语句。当我们打开了 Query Cache功能，MySQL在接受到一条select语句的请求后，如果该语句满足Query Cache的要求(未显式说明不允许使用Query Cache，或者已经显式申明需要使用Query Cache)，MySQL会直接根据预先设定好的HASH算法将接受到的select语句以字符串方式进行hash，然后到Query Cache中直接查找是否已经缓存。也就是说，如果已经在缓存中，该select请求就会直接将数据返回，从而省略了后面所有的步骤(如SQL语句的解析，优化器优化以及向存储引擎请求数据等)，极大的提高性能。根据MySQL用户手册，使用查询缓冲最多可以达到238%的效率。
当然，Query Cache也有一个致命的缺陷，那就是当某个表的数据有任何任何变化，都会导致所有引用了该表的select语句在Query Cache中的缓存数据失效。所以，当我们的数据变化非常频繁的情况下，使用Query Cache可能会得不偿失",
						'value'	=> '',	
						),
					array(
						'name'	=> 'sort_buffer_size',
						'ps'	=> "sort_buffer_size是MySql执行排序使用的缓冲大小。如果想要增加ORDER BY的速度，首先看是否可以让MySQL使用索引而不是额外的排序阶段。如果不能，可以尝试增加sort_buffer_size变量的大小",
						'value'	=> '',	
						),
					array(
						'name'	=> 'thread_concurrency',
						'ps'	=> "thread_concurrency的值的正确与否, 对mysql的性能影响很大, 在多个cpu(或多核)的情况下，错误设置了thread_concurrency的值, 会导致mysql不能充分利用多cpu(或多核), 出现同一时刻只能一个cpu(或核)在工作的情况。
thread_concurrency应设为CPU核数的2倍. 比如有一个双核的CPU, 那thread_concurrency  的应该为4; 2个双核的cpu, thread_concurrency的值应为8.",
						'value'	=> '',	
						),
					array(
						'name'	=> 'tmp_table_size',
						'ps'	=> "tmp_table_size是MySql的heap （堆积）表缓冲大小。所有联合在一个DML指令内完成，并且大多数联合甚至可以不用临时表即可以完成。大多数临时表是基于内
存的(HEAP)表。具有大的记录长度的临时表 (所有列的长度的和)或包含BLOB列的表存储在硬盘上。如果某个内部heap（堆积）表大小超过tmp_table_size，MySQL可以根据需要自
动将内存中的heap表改为基于硬盘的MyISAM表。还可以通过设置tmp_table_size选项来增加临时表的大小。也就是说，如果调高该值，MySql同时将增加heap表的大小，可达到提高
联接查询速度的效果。",
						'value'	=> '',	
						),
					array(
						'name'	=> 'key_buffer_size',
						'ps'	=> "key_buffer_size是用于索引块的缓冲区大小，增加它可得到更好处理的索引(对所有读和多重写)，对MyISAM表性能影响最大的一个参数。如果你使它太大，系统将开始换页并且真的变慢了。严格说是它决定了数据库索引处理的速度，尤其是索引读的速度。对于内存在4GB左右的服务器该参数可设置为256M或384M.",
						'value'	=> '',	
						),
					array(
						'name'	=> 'read_buffer_size',
						'ps'	=> "read_buffer_size 是MySql读入缓冲区大小。对表进行顺序扫描的请求将分配一个读入缓冲区，MySql会为它分配一段内存缓冲区。read_buffer_size变量控制这一
缓冲区的大小。如果对表的顺序扫描请求非常频繁，并且你认为频繁扫描进行得太慢，可以通过增加该变量值以及内存缓冲区大小提高其性能.",
						'value'	=> '',	
						),
					array(
						'name'	=> 'read_rnd_buffer_size',
						'ps'	=> "read_rnd_buffer_size 是MySql的随机读缓冲区大小。当按任意顺序读取行时(例如，按照排序顺序)，将分配一个随机读缓存区。进行排序查询时，MySql会首先扫描一遍该缓冲，以避免磁盘搜索，提高查询速度，如果需要排序大量数据，可适当调高该值。但MySql会为每个客户连接发放该缓冲空间，所以应尽量适当设置该值，以避免内存开销过大。",
						'value'	=> '',	
						),
					array(
						'name'	=> 'innodb_buffer_pool_size',
						'ps'	=> "innodb_buffer_pool_size:主要针对InnoDB表性能影响最大的一个参数。功能与Key_buffer_size一样。InnoDB占用的内存，除innodb_buffer_pool_size用于存储页面缓存数据外，另外正常情况下还有大约8%的开销，主要用在每个缓存页帧的描述、adaptive hash等数据结构，如果不是安全关闭，启动时还要恢复的话，还要另开大约12%的内存用于恢复，两者相加就有差不多21%的开销。假设：12G的innodb_buffer_pool_size，最多的时候InnoDB就可能占用到14.5G的内存。若系统只有16G，而且只运行MySQL，且MySQL只用InnoDB，
那么为MySQL开12G，是最大限度地利用内存了。
另外InnoDB和 MyISAM 存储引擎不同， MyISAM 的 key_buffer_size 只能缓存索引键，而 innodb_buffer_pool_size 却可以缓存数据块和索引键。适当的增加这个参数的大小，可以有效的减少 InnoDB 类型的表的磁盘 I/O 。
当我们操作一个 InnoDB 表的时候，返回的所有数据或者去数据过程中用到的任何一个索引块，都会在这个内存区域中走一遭。",
						'value'	=> '',	
						),
					array(
					'name'	=> 'innodb_log_buffer_size',
					'ps'	=> "innodb_log_buffer_size  这是InnoDB存储引擎的事务日志所使用的缓冲区。类似于Binlog Buffer，InnoDB在写事务日志的时候，为了提高性能，也是先将信息写入Innofb Log Buffer中，当满足innodb_flush_log_trx_commit参数所设置的相应条件(或者日志缓冲区写满)之后，才会将日志写到文件 (或者同步到磁盘)中。可以通过innodb_log_buffer_size 参数设置其可以使用的最大内存空间。
   InnoDB 将日志写入日志磁盘文件前的缓冲大小。理想值为 1M 至 8M。大的日志缓冲允许事务运行时不需要将日志保存入磁盘而只到事务被提交(commit)。 因此，如果有大的事务处理，设置大的日志缓冲可以减少磁盘I/O。 在 my.cnf中以数字格式设置。
默认是8MB，系的如频繁的系统可适当增大至4MB～8MB。当然如上面介绍所说，这个参数实际上还和另外的flush参数相关。一般来说不建议超过32MB",
					'value'	=> '',	
					),
					array(
					'name'	=> 'innodb_log_file_size',
					'ps'	=> "此参数确定数据日志文件的大小，以M为单位，更大的设置可以提高性能，但也会增加恢复故障数据库所需的时间",
					'value'	=> '',	
					),
					array(
					'name'	=> 'innodb_additional_mem_pool_size',
					'ps'	=> "innodb_additional_mem_pool_size 设置了InnoDB存储引擎用来存放数据字典信息以及一些内部数据结构的内存空间大小，所以当我们一个MySQL Instance中的数据库对象非常多的时候，是需要适当调整该参数的大小以确保所有数据都能存放在内存中提高访问效率的。
这个参数大小是否足够还是比较容易知道的，因为当过小的时候，MySQL会记录Warning信息到数据库的error log中，这时候你就知道该调整这个参数大小了。根据MySQL手册，对于2G内存的机器，推荐值是20M, 32G内存的 100M",
					'value'	=> '',	
					)
				);
	for($i=0;$i<count($caches);$i++){
		$rep = "/".$caches[$i]['name']."\s*=\s*([0-9kKmM]+)/";
		preg_match($rep, $conf,$tmp);
		if(!$tmp[1]) continue;
		$caches[$i]['value'] = $tmp[1];
	}
	
	ajax_return($caches);
}

//接口动作
$_SESSION['crontab']['status'] = null;
if(isset($_GET['action'])){
	$_GET['action']();
	exit;
}


$ConfigInfo = GetConfigInfo();
$Panel = GetPanelBinding();

//包含头部与菜单
require './public/head.html';
require './public/menu.html';
require './public/config.html';
require './public/footer.html';
?>
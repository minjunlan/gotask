<?php
return array(
	array(
	'name'	=>'七牛云存储',
	'type'	=>'计划任务',
	'ps'	=>'将网站或数据库打包备份到七牛对象存储空间,七牛提供10GB免费存储空间, <a class="link" href="https://portal.qiniu.com/signup?code=3liz7nbopjd5e" target="_blank">点击申请</a>',
	'status'=>false,
	'opt'	=>'qiniu',
	'script'=>'qiniu.sh',
	'check' =>array('/usr/lib/python2.6/site-packages/qiniu/auth.py','/usr/lib/python2.7/site-packages/qiniu/auth.py')
	)
);
?>
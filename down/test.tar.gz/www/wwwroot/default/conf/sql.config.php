<?php
return array(
	'DB_HOST'		=>	'localhost',	//主机地址
	'DB_NAME'		=>	'bt_default',	//数据库名
	'DB_PORT'		=>	3306,			//端口
	'DB_PREFIX'		=>	'bt_',			//表前缀
	'DB_CHARSET'	=>	'utf8',			//数据库编码
	'DB_USER'		=>	'bt_default',	//用户名
	'DB_PWD'		=>	'623de2cf7c2a',		//密码
);
?>

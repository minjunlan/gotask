define([
	"./deletedIds"
], function( deletedIds ) {
	return deletedIds.slice;
});

define(function() {
	return typeof undefined;
});
